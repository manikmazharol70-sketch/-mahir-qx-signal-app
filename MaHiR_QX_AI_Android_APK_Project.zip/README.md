# MaHiR QX AI - Android APK

This is the Android version of the MaHiR QX AI Quotex Helper.

## What it does
- Mobile-friendly signal/helper UI
- Pair selector
- CALL/PUT signal display
- Confidence/model score display
- RSI/EMA-style metrics display
- Manual confirmation log

## Important
This build does **not** automatically place Quotex trades and does not bypass Quotex protections. A displayed confidence value is not a guarantee of profit.

## Build APK
The project is intended for Buildozer/python-for-android.

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install buildozer cython
buildozer android debug
```

The APK should appear under `bin/`.

## GitHub Actions
A workflow file is included under `.github/workflows/build-apk.yml`. Push this project to GitHub and Actions can build the debug APK on Ubuntu.
