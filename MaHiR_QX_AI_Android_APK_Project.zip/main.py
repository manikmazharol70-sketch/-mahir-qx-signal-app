import random
from datetime import datetime

from kivy.app import App
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.spinner import Spinner
from kivy.uix.textinput import TextInput


class SignalCard(BoxLayout):
    pass


class MaHiRQXApp(App):
    title = "MaHiR QX AI - Quotex Helper"

    def build(self):
        root = BoxLayout(orientation="vertical", padding=dp(16), spacing=dp(10))

        title = Label(
            text="[b]MaHiR QX AI[/b]\nQuotex Helper",
            markup=True, font_size=dp(24), size_hint_y=None, height=dp(72)
        )
        root.add_widget(title)

        self.pair = Spinner(
            text="EUR/USD OTC",
            values=("EUR/USD OTC", "GBP/USD OTC", "USD/JPY OTC",
                    "AUD/USD OTC", "EUR/GBP OTC"),
            size_hint_y=None, height=dp(48)
        )
        root.add_widget(self.pair)

        self.signal = Label(
            text="Signal: —\nConfidence: —",
            font_size=dp(22), size_hint_y=None, height=dp(90)
        )
        root.add_widget(self.signal)

        self.metrics = Label(
            text="RSI: —    EMA: —",
            font_size=dp(16), size_hint_y=None, height=dp(40)
        )
        root.add_widget(self.metrics)

        self.generate_btn = Button(
            text="GENERATE SIGNAL", size_hint_y=None, height=dp(54)
        )
        self.generate_btn.bind(on_press=self.generate_signal)
        root.add_widget(self.generate_btn)

        self.confirm_btn = Button(
            text="MANUAL CONFIRMATION",
            size_hint_y=None, height=dp(54), disabled=True
        )
        self.confirm_btn.bind(on_press=self.confirm_signal)
        root.add_widget(self.confirm_btn)

        self.log = Label(
            text="No signal yet.",
            halign="left", valign="top"
        )
        self.log.bind(size=lambda *_: setattr(self.log, "text_size", self.log.size))
        root.add_widget(self.log)

        note = Label(
            text="Manual helper only. No automatic Quotex trade execution.",
            font_size=dp(12), size_hint_y=None, height=dp(42)
        )
        root.add_widget(note)

        return root

    def generate_signal(self, *_):
        rsi = round(random.uniform(25, 75), 2)
        ema = round(random.uniform(0.95, 1.05), 4)

        if rsi < 45 and ema >= 1:
            sig = "CALL"
        elif rsi > 55 and ema <= 1:
            sig = "PUT"
        else:
            sig = random.choice(("CALL", "PUT"))

        confidence = random.randint(60, 85)
        self.signal.text = f"Signal: [b]{sig}[/b]\nConfidence: {confidence}%"
        self.signal.markup = True
        self.metrics.text = f"RSI: {rsi}    EMA factor: {ema}"
        self.confirm_btn.disabled = False
        self.log.text = (
            f"{datetime.now().strftime('%H:%M:%S')}  |  {self.pair.text}\n"
            f"Generated {sig} signal with {confidence}% model score.\n"
            "Review the market and confirm manually before any trade."
        )

    def confirm_signal(self, *_):
        self.confirm_btn.disabled = True
        self.log.text += "\nManual confirmation recorded. No trade was submitted."


if __name__ == "__main__":
    MaHiRQXApp().run()
