[app]
title = MaHiR QX AI - Quotex Helper
package.name = mahirqxai
package.domain = com.mahir.qxai
source.dir = .
source.include_exts = py,png,jpg,kv,json
version = 1.0.0
requirements = python3,kivy
orientation = portrait
fullscreen = 0

[buildozer]
log_level = 2
warn_on_root = 0

[app:android]
android.api = 35
android.minapi = 21
android.ndk = 28c
android.archs = arm64-v8a,armeabi-v7a
android.accept_sdk_license = True
