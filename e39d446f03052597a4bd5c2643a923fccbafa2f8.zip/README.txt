# VideoStyle Signal App

এটি ভিডিওর মতো ডার্ক ট্রেডিং UI-র একটি নিজস্ব DEMO signal app।
এটি কোনো ব্রোকার/ওয়েবসাইট হ্যাক বা নিয়ন্ত্রণ করে না এবং বাস্তব ট্রেড অটোমেট করে না।

## Android APK build
Linux/Ubuntu-তে:

    sudo apt update
    sudo apt install -y python3-pip git zip unzip openjdk-17-jdk
    pip3 install --user buildozer cython
    cd signal_app_project
    buildozer android debug

APK সাধারণত bin/ ফোল্ডারে তৈরি হবে।

## কীভাবে signal তৈরি হচ্ছে
ডেমোতে random-walk price data এবং একটি simple fast/slow moving-average comparison ব্যবহার করা হয়েছে।
বাস্তব মার্কেট ডেটা ব্যবহার করতে হলে অনুমোদিত market-data API যুক্ত করতে হবে।
